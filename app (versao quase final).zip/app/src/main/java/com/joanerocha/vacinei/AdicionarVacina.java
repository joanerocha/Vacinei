package com.joanerocha.vacinei;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import com.orm.SugarContext;

import java.util.ArrayList;

public class AdicionarVacina extends AppCompatActivity {

    EditText nomeVacina;
    EditText doseVacina;
    EditText dataVacina;
    EditText loteVacina;
    EditText localvacina;

    Button validarVacina;
    Button cancelar;

    Bundle bAdicionarVacina;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar_vacina);

        nomeVacina = (EditText) findViewById(R.id.nomeVacina);
        doseVacina = (EditText) findViewById(R.id.doseVacina);
        dataVacina = (EditText) findViewById(R.id.dataVacina);
        loteVacina = (EditText) findViewById(R.id.lote);
        localvacina = (EditText) findViewById(R.id.local);

        bAdicionarVacina = getIntent().getExtras();

        Log.d("testeSus", "Numero do sus: "+bAdicionarVacina.getString("susPaciente").toString());
//        Toast.makeText(this, bAdicionarVacina.getString("susPaciente"), Toast.LENGTH_SHORT).show();

        validarVacina = (Button) findViewById(R.id.validarVacina);
        cancelar = (Button) findViewById(R.id.cancelarVacina);
    }

    public void voltarCartaoVacina(View view) {
        Intent voltarTelaVacina = new Intent(this, CartaoVacina.class);
        voltarTelaVacina.putExtras(bAdicionarVacina);
        startActivity(voltarTelaVacina);
        finish();
    }

    public Boolean verificaCampoPreenchido() {
        String nomeV = nomeVacina.getText().toString();
        String doseV = doseVacina.getText().toString();
        String dataV = dataVacina.getText().toString();
        String loteV = loteVacina.getText().toString();
        String localV = localvacina.getText().toString();
        //String idade = idadeP.getText().toString();

        if (nomeV.equals("") || doseV.equals("") || dataV.equals("") || loteV.equals("") || localV.equals("")) {
            return false;
        }
        return true;
    }

    private AlertDialog alertaOk;

    public void alertaCadastroVacina(final View view) {
        if (verificaCampoPreenchido() == false) { // Verifica se os campos estão vazios
            Toast.makeText(AdicionarVacina.this, "Preencha os dados", Toast.LENGTH_SHORT).show();  // Mensagem de campos vazios
        } else {
                final AlertDialog.Builder alerta = new AlertDialog.Builder(this); // Finaliza o alerta
                alerta.setTitle("Confirmação de Cadastro");
                alerta.setMessage("Vacina cadastrada com sucesso!");
                alerta.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        voltarCartaoVacina(view);
                    }
                });
                alertaOk = alerta.create();
                alertaOk.show();
                String nomeV = nomeVacina.getText().toString();
                String doseV = doseVacina.getText().toString();
                String dataV = dataVacina.getText().toString();
                String loteV = loteVacina.getText().toString();
                String localV = localvacina.getText().toString();
                String susP = bAdicionarVacina.getString("susPaciente").toString();
//                Vacina v = new Vacina(nomeVacina.getText().toString(), doseVacina.getText().toString(), dataVacina.getText().toString(), loteVacina.getText().toString(), localvacina.getText().toString(), bAdicionarVacina.getString("susPaciente").toString());
//                Vacina vacina = new Vacina(nomeV, doseV, dataV, localV, susP);
                Vacina vacina = new Vacina(nomeV, doseV, dataV, loteV, localV, susP);
                vacina.save(); // salvar
            }
        }

//
}
