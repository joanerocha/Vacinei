package com.joanerocha.vacinei;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;
import android.widget.Toast;

import com.orm.SugarContext;

import java.util.ArrayList;
import java.util.List;

public class CartaoVacina extends AppCompatActivity implements AdapterView.OnItemClickListener{

    private ListView list;
    Bundle b;

    Vacina vacina = new Vacina();

    List<Vacina> listaVacina = vacina.listAll(Vacina.class);
    List<Vacina> nomeVacina = new ArrayList<>();


//    Paciente paciente = new Paciente();
//    List<Paciente> listaPaciente = paciente.listAll(Paciente.class);
//    List<String> susPaciente = new ArrayList<>();
//

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cartao_vacina);
        SugarContext.init(this);

        list = (ListView) findViewById(R.id.listViewVacina);
//        list.setAdapter(new VacinaAdapter(this));
//        list.setOnItemClickListener(this);

        b = getIntent().getExtras();

//        Log.d("testeSus", "Numero do sus: "+b.getString("susPaciente").toString());



//        for(Paciente paciente:listaPaciente){
//            if(paciente.getSus()!=null) {
//                susPaciente.add(paciente.getSus());
//                Log.i("listando", "vacina: " + paciente.getSus());
//            }
//        }
        boolean temVacina = false;
        Log.d("vaidanao", "Chegou isso: "+b.getString("susPaciente").toString());
        for(Vacina vacina:listaVacina){
            if(vacina.getSusPaciente().equals(b.getString("susPaciente").toString())) {
//                nomeVacina.add(vacina.getNomeVacina());
                nomeVacina.add(vacina);
                Log.d("listando", "vacina: " + vacina.getNomeVacina());
//                list = (ListView) findViewById(R.id.listViewVacina);
//                list.setAdapter(new VacinaAdapter(this));
                temVacina = true;
            }
        }
        if(!temVacina){
            Toast.makeText(this, "Não tem vacina", Toast.LENGTH_SHORT).show();
        }


//        AutoCompleteTextView vacinas = (AutoCompleteTextView) findViewById(R.id.completeVacina);
//        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nomeVacina);
//        vacinas.setAdapter(adaptador);
//
        list = (ListView) findViewById(R.id.listViewVacina);
        list.setAdapter(new TesteVacinasAdapter(this, nomeVacina));
//        list.setOnItemClickListener(new AdapterView.OnItemClickListener(){
//
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                Vacina vacina = (Vacina) adapterView.getAdapter().getItem(i);
//                Intent cartao = new Intent(CartaoVacina.this, CartaoVacina.class);
//                startActivity(cartao);
//            }
//        });
//        listaVacina = Vacina.findWithQuery(Vacina.class, "Select * from Vacina where sus = ?", result.getContents());
    }
    public void adicionarVacina(View view){
        Intent adicionarVacina = new Intent(this, AdicionarVacina.class);
        adicionarVacina.putExtras(b);
        startActivity(adicionarVacina);
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        SugarContext.terminate();
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Vacina vacina = (Vacina) adapterView.getAdapter().getItem(i);

    }
}
