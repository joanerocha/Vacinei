package com.joanerocha.vacinei;

import com.orm.SugarRecord;
import com.orm.dsl.Table;

import java.util.Date;

/**
 * Created by Joane Rocha on 07/08/2017.
 */
@Table
public class Vacina extends SugarRecord {
    private long idVacina;
    private String nomeVacina;
    private String dose;
    private String data;
    private String local;

    public Vacina() {
    }

    public Vacina(String nomeVacina,  String dose, String data, String local) {
    //    this.idVacina = idVacina;
        this.nomeVacina = nomeVacina;
        this.dose = dose;
        this.data = data;
        this.local = local;
    }

    @Override
    public String toString() {
        return "Vacina{" +
                "id =" + idVacina +
                ", nome ='" + nomeVacina + '\'' +
                ", dose =" + dose +
                ", data =" + data +
                ", local =" + local +
                '}';
    }

    public long getIdVacina() {
        return idVacina;
    }

    public void setIdVacina(long idVacina) {
        this.idVacina = idVacina;
    }

    public String getNomeVacina() {
        return nomeVacina;
    }

    public void setNomeVacina(String nomeVacina) {
        this.nomeVacina = nomeVacina;
    }

    public String getDose() {
        return dose;
    }

    public void setDose(String dose) {
        this.dose = dose;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }
}
