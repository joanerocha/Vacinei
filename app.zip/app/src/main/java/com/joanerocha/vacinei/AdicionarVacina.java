package com.joanerocha.vacinei;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import java.util.ArrayList;

public class AdicionarVacina extends AppCompatActivity {

    EditText nomeVacina;
    EditText dataVacina;
    EditText loteVacina;
    EditText localvacina;
    Button validarVacina;
    Button cancelar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_paciente);

        nomeVacina = (EditText) findViewById(R.id.nomeVacina);
        dataVacina = (EditText) findViewById(R.id.dataVacina);
        loteVacina = (EditText) findViewById(R.id.lote);
        localvacina = (EditText) findViewById(R.id.local);


        validarVacina = (Button) findViewById(R.id.validarVacina);
        cancelar = (Button) findViewById(R.id.cancelarVacina);
    }

    public void voltarCartaoVacina(View view) {
        Intent voltarTelaVacina = new Intent(this, CartaoVacina.class);
        startActivity(voltarTelaVacina);
        finish();
    }

    public Boolean verificaCampoPreenchido() {
        String nomeV = nomeVacina.getText().toString();
        String dataV = dataVacina.getText().toString();
        String loteV = loteVacina.getText().toString();
        String localV = localvacina.getText().toString();
        //String idade = idadeP.getText().toString();

        if (nomeV.equals("") || dataV.equals("") || loteV.equals("") || localV.equals("")) {
            return false;
        }
        return true;
    }

    private AlertDialog alertaOk;

    public void alertaCadastroVacina(final View view) {
        if (verificaCampoPreenchido() == false) { // Verifica se os campos estão vazios
            Toast.makeText(AdicionarVacina.this, "Preencha os dados", Toast.LENGTH_SHORT).show();  // Mensagem de campos vazios
        } else {
                final AlertDialog.Builder alerta = new AlertDialog.Builder(this); // Finaliza o alerta
                alerta.setTitle("Confirmação de Cadastro");
                alerta.setMessage("Vacina cadastrada com sucesso!");
                alerta.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        voltarCartaoVacina(view);
                    }
                });
                alertaOk = alerta.create();
                alertaOk.show();
                Vacina v = new Vacina(nomeVacina.getText().toString(), dataVacina.getText().toString(), loteVacina.getText().toString(), localvacina.getText().toString());
                Vacina.save(v); // salvar

            }
        }
    public void cancelar(final View view){
        voltarCartaoVacina(view);
    }
}
