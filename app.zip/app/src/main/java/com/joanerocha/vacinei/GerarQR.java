package com.joanerocha.vacinei;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class GerarQR extends AppCompatActivity {

    EditText susP;
    Button gen_btn;
    ImageView image;
    String text2QR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gerar_qr);
       // setContentView(R.layout.activity_cadastro_paciente);

        //estava tentando pegar o sus de outr activity, esqueci como faz

//        Bundle bundle = new Bundle();
//        bundle.putString("Número SUS", susP.getText(susP));
////        Intent intent = new Intent(context, MinhaOutraActivity.class);
////        intent.putExtras(bundle);
//        startActivity(intent);

        // tentei usar o Bundle

        susP = (EditText) findViewById(R.id.sus);
        gen_btn = (Button) findViewById(R.id.gen_btn);
        image = (ImageView) findViewById(R.id.image);


        gen_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text2QR = susP.getText().toString().trim();
                MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                try{
                    BitMatrix bitMatrix = multiFormatWriter.encode(text2QR, BarcodeFormat.QR_CODE, 200, 200);
                    BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                    Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                    image.setImageBitmap(bitmap);
                }catch (WriterException we){
                    we.printStackTrace();
                }
            }

        });
    }
}
