package com.joanerocha.vacinei;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AlertDialogLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.List;

public class CadastroPaciente extends AppCompatActivity {

    EditText nomeP;
    EditText susP;
    EditText cpfP;
    EditText emailP;
    EditText idadeP;

    ImageView image;
    String text2QR;
    Button gen_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_paciente);

        nomeP = (EditText) findViewById(R.id.nomePaciente);
        susP = (EditText) findViewById(R.id.sus);
        cpfP = (EditText) findViewById(R.id.cpf);
        emailP = (EditText) findViewById(R.id.emailPaciente);
        idadeP = (EditText) findViewById(R.id.idade);

        gen_btn = (Button) findViewById(R.id.gen_btn);
        image = (ImageView) findViewById(R.id.image);



    }



    public void voltarTelaEnfermeiro(View view) {
        Intent voltarTelaEnfermeiro = new Intent(this, Home.class);
        startActivity(voltarTelaEnfermeiro);
        finish();
    }
    public Boolean verificaCampoPreenchido() {
        String nomePaciente = nomeP.getText().toString();
        String sus = susP.getText().toString();
        String cpf = cpfP.getText().toString();
        String email = emailP.getText().toString();
        //String idade = idadeP.getText().toString();

        if (nomePaciente.equals("") || sus.equals("") || cpf.equals("") || email.equals("")) {
            return false;
        }
        return true;
    }
    public boolean verificandoSusExistente() {
        String verificaSus = susP.getText().toString();
        Boolean flagSus = true; // era true
        Paciente p = new Paciente();
        List<Paciente> listapaciente = p.listAll(Paciente.class);

        for (Paciente paciente : listapaciente) {
            if (paciente.getSus().equals(verificaSus)) {
                flagSus = false; // era false
            }
        }
        return flagSus;
    }
    private AlertDialog alertaOk;
    private AlertDialog alertaQR;

    public void gerarQRCode(View view) {

        if (verificaCampoPreenchido() == false) { // Verifica se os campos estão vazios
            Toast.makeText(CadastroPaciente.this, "Preencha os dados", Toast.LENGTH_SHORT).show();  // Mensagem de campos vazios
        } else {
            if (verificandoSusExistente() == false) {
                Toast.makeText(CadastroPaciente.this, "SUS existente!", Toast.LENGTH_SHORT).show(); // Verifica se o CRM ja existe
            }

            gen_btn.setOnClickListener(new View.OnClickListener() { //começa aqui
                @Override
                public void onClick(View view) {
                    text2QR = susP.getText().toString().trim();
                    MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                    try {
                        BitMatrix bitMatrix = multiFormatWriter.encode(text2QR, BarcodeFormat.QR_CODE, 200, 200);
                        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                        Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                        image.setImageBitmap(bitmap);

//                        LayoutInflater li = getLayoutInflater();
//                        View v = li.inflate(R.layout.activity_cadastro_paciente, null);
//
//                        view.findViewById(R.id.gen_btn).setOnClickListener(new View.OnClickListener() {
//                            public void onClick(View arg0) {
//                                //exibe um Toast informativo.
//                                Toast.makeText(CadastroPaciente.this, "alerta.dismiss()", Toast.LENGTH_SHORT).show();
//                                //desfaz o alerta.
//                                alertaQR.dismiss();
//                            }
//                        });
//
//                        AlertDialog.Builder builder = new AlertDialog.Builder(CadastroPaciente.this);
//                        builder.setTitle("QR Code Paciente");
//                        builder.setView(view);
//                        alertaQR = builder.create();
//                        alertaQR.show();
////

                    } catch (WriterException we) {
                        we.printStackTrace();
                    }
                }
            }); //termina aqui
        }
    }

    public void alertaCadastroPaciente(final View view) {
        if (verificaCampoPreenchido() == false) { // Verifica se os campos estão vazios
            Toast.makeText(CadastroPaciente.this, "Preencha os dados", Toast.LENGTH_SHORT).show();  // Mensagem de campos vazios
        } else {
            if (verificandoSusExistente() == false) {
                Toast.makeText(CadastroPaciente.this, "SUS existente!", Toast.LENGTH_SHORT).show(); // Verifica se o CRM ja existe
            } else {
//                if (!senhaE.getText().toString().equals(csenha.getText().toString())) { // Verifica se as senhas são diferentes
//                    Toast.makeText(CadastroEnfermeiro.this, "As senhas não coincidem!", Toast.LENGTH_SHORT).show(); // Mostra Alerta de senhas diferentes
//                } else {
                final AlertDialog.Builder alerta = new AlertDialog.Builder(this); // Finaliza o alerta
                alerta.setTitle("Confirmação de Cadastro");
                alerta.setMessage("Paciente cadastrado com sucesso!");
                alerta.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        voltarTelaEnfermeiro(view);
                    }
                });
                alertaOk = alerta.create();
                alertaOk.show();
                Paciente p = new Paciente(nomeP.getText().toString(), susP.getText().toString(), cpfP.getText().toString(), emailP.getText().toString(), Integer.parseInt(idadeP.getText().toString()));
                Paciente.save(p); // salvar

            }
        }
    }
    public void TelaGerarQR(View view) {
        Intent gerarQR = new Intent(this, GerarQR.class);
        startActivity(gerarQR);
        finish();
    }
}

