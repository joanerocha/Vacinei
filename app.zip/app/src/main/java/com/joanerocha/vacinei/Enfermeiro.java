package com.joanerocha.vacinei;

import com.orm.SugarRecord;
import com.orm.dsl.Table;

/**
 * Created by Joane Rocha on 07/08/2017.
 */
@Table
public class Enfermeiro extends SugarRecord {
    private long idEnfermeiro;
    private String nomeEnfermeiro;
    private String coren;
    private String email;
    private String senha;

    public Enfermeiro() {

    }

    public Enfermeiro(String nomeEnfermeiro, String coren, String email, String senha) {
        this.nomeEnfermeiro = nomeEnfermeiro;
        this.coren = coren;
        this.email = email;
        this.senha = senha;
    }

//    public long getIdEnfermeiro() {
//        return idEnfermeiro;
//    }
//
//    public void setIdEnfermeiro(long idEnfermeiro) {
//        this.idEnfermeiro = idEnfermeiro;
//    }
//
//    public String getNomeEnfermeiro() {
//        return nomeEnfermeiro;
//    }
//
//    public void setNomeEnfermeiro(String nomeEnfermeiro) {
//        this.nomeEnfermeiro = nomeEnfermeiro;
//    }

    public String getCoren() {
        return coren;
    }

//    public void setCoren(String coren) {
//        this.coren = coren;
//    }

    public String getSenha() {
        return senha;
    }

//    public void setSenha(String senha) {
//        this.senha = senha;
//    }
//
//    public String getEmail() {
//        return email;
//    }

//    public void setEmail(String email) {
//        this.email = email;
//    }

    @Override
    public String toString() {
        return "Enfermeiro{" +
                "idEnfermeiro=" + idEnfermeiro +
                ", nomeEnfermeiro='" + nomeEnfermeiro + '\'' +
                ", coren='" + coren + '\'' +
                ", email='" + email + '\'' +
                ", senha='" + senha + '\'' +
                '}';
    }
}
